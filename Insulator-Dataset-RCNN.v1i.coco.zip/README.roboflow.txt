
Insulator-Dataset-RCNN - v1 2021-03-31 9:13pm
==============================

This dataset was exported via roboflow.ai on March 31, 2021 at 3:44 PM GMT

It includes 15 images.
Insulator are annotated in COCO format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

No image augmentation techniques were applied.


